# Link - this shit is not finished and I don't know if I'll ever finish it.

It's a link mod I was working on, then I saw someone already make one. This is what I had and I don't remember how much I've done but it's probably jank as fuck.
Created by Ethanol 10. For any issues or bug reports, contact me on the RoR2 Modding discord, or to me directly: @ethanol10
I probably won't fix any bugs. Play this jank at your own risk.

# What is Ethanol 11?
A graveyard for mods, or something I might be working on.

## Support me on Ko-fi! (This doesn't guarantee this mod being finished.)
Even if you pay me to finish this there's a chance I may not even finish it. So don't donate expecting that. There was a bunch of jank that I just didn't feel like dealing with after a certain point so it's probably gonna stay like this. Maybe when I feel like it I'll come back to this and cringe at what I wrote before.

<a href="https://ko-fi.com/ethanol10" target="_blank">
  <img width="400" src="https://cdn.discordapp.com/attachments/928130606662049892/952521134526590996/unknown.png"/>
</a>  
  
# Major release details:
- v0.0.0.0.0.0.0.0.0.0.0.0.1
    - Release

## Skills
From what I remember programming:
- Link has 3 loadouts you can play with, the "special" loadout is broken, though other than the sword and the bomb, the rest is either jank or just not even implemented. 
- Even then there's no voice lines or anything.
- No VFX.
- Bomb can be thrown and kicked around, but I don't really see much use with it.
- Master sword moveset is bound to extra skills 1? man I don't remember anything.
- You can spam me with fix requests but I may not fix them. Maybe.

# Old Changelog
<details>
<summary>Click to expand previous patch notes:</summary>
    - v0.0.0.0.0.0.0.0.0.0.0.0.1
        - Release
</details>

## Future Plans

## Known Issues

 
## Credits
- Rob's HenryMod -> Template
- Nintendo/Bandai Namco -> Model + Texturing + Animations + Sounds (no this is not officially endorsed by either company)